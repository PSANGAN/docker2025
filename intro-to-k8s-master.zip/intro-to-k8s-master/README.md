# intro-to-k8s

Assets used for the production of the Introduction to Kubernetes course on Cloud Academy
<a target="_blank" href="https://cloudacademy.com/course/introduction-to-kubernetes/">https://cloudacademy.com/course/introduction-to-kubernetes</a>

Follow along with a multi-node Kubernetes cluster in the [Introduction to Kubernetes Playground lab](https://cloudacademy.com/lab/introduction-kubernetes-playground/)
